#### A

Na této stránce jsem našel něco, co se myslím týká i mojí situace.<br><br>

<div class="do-not-break-out" markdown="1">
[https://www.creativecommons.cz/pro-autory/publikace-del/](https://www.creativecommons.cz/pro-autory/publikace-del/)<br>
</div>

<div class="citace">
„Vlastníte materiál, který chcete licencovat? Pokud ne, jste
oprávněni tento materiál licencovat? Licenci Creative Commons
nemůžete použít na materiál, který nevlastníte nebo nejste k
takovému kroku oprávněni.“<br>
</div>

Podobné vyjádření jsem pak našel na této stránce.<br><br>

<div class="do-not-break-out" markdown="1">
[https://wiki.creativecommons.org/wiki/Considerations_for_licensors_and_licensees](https://wiki.creativecommons.org/wiki/Considerations_for_licensors_and_licensees)
<br>
</div>

<div class="citace">
„If the material includes rights held by others, make sure to get
permission to sublicense those rights under the CC license.“
</div>

Mohla by mi Buddhistická společnost Západní Austrálie dát povolení,
abych celý text titulků zveřejnil pod licencí CC Uveďte původ 4.0?
Dalo by se to vyřešit tímto způsobem?<br>
