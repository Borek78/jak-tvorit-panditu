<!-- prettier-ignore-start -->
<div id="anchor-odkazy" markdown="1" >
### Odkazy na této stránce
</div >
<div class="no-link-underline" markdown="1" >
<span>1.</span> [YouTube kanál PANDITA CZ](https://www.youtube.com/channel/UC1IIp3Yo_PaJPsEU9BUk1ew) <br>
<span>2.</span> [YouTube kanál Sasana.pl](https://www.youtube.com/user/sasanaPL) <br>
<span>3.</span> [Centro Meditazione di Pian dei Ciliegi](https://www.piandeiciliegi.it/en)<br>
<span>4.</span> [Teoh Visu](https://visuteoh.net/cesky/visu%20teoh)<br>
<span>5.</span> [YouTube kanál Buddhist Society of Western Australia](https://www.youtube.com/user/BuddhistSocietyWA)<br>
<span>6.</span> [YouTube kanál Ajahn Brahm česky](https://www.youtube.com/channel/UCUr-lRBB59mFLyKFhAAbXbg)<br>
<span>7.</span> [DGD – Dalibor Pavlík](https://drive.google.com/drive/u/0/my-drive) <br>
<span>8.</span> [Autorský zákon (zákon č. 121/2000)](https://www.zakonyprolidi.cz/cs/2000-121) [[§11- (4)](https://www.zakonyprolidi.cz/cs/2000-121#p11-4), [§26 - (1)](https://www.zakonyprolidi.cz/cs/2000-121#p26-1)].<br>
<span>9.</span> [CC licence](https://www.creativecommons.cz/uvod/) <br>
<span>10.</span> [Oprávnění k použití za podmínek licence CC Uveďte původ 4.0](https://drive.google.com/drive/u/0/folders/16nYDrS2RoqtO4ttlh4zDNIQW5lw3t0vA)<br>
<span>11.</span> [Licence Uveďtě původ 4.0 Mezinárodní (CC-BY)](https://creativecommons.org/licenses/by/4.0/deed.cs)<br>
</div>

### Odkazy na DGD

<div class="no-link-underline" markdown="1" >
[Dalibor Pavlík](https://drive.google.com/drive/u/0/my-drive)
</div>


<!-- prettier-ignore-end -->
