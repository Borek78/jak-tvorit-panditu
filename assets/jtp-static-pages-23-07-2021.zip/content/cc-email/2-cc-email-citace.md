<div class="citace" markdown="1">
V souvislosti s licencemi Creative Commons se lze setkat ještě
se dvěma nástroji. Konkrétně se jedná o „licenci“ CC0 (CC Zero) a tzv.
Public Domain Mark. <br><br>

• CC0 je zamýšlen jako nástroj, kterým se  autor vzdává veškerých
práv ke  konkrétnímu dílu. V České republice by ovšem takové právní
jednání nebylo platné, neboť není právem dovolené. CC Zero na tyto
situace ovšem pamatuje a v případě nedovolenosti takového jednání
stanovuje, že se jedná o maximální možnou právem dovolenou licenci
(„Public License Fallback“) – tedy licenci Creative Commons „Uveďte
autora“ 4.0. V rámci bezproblémové aplikace nedoporučujeme tento
nástroj užívat a místo něj raději používat nejliberálnější univerzální
licenci [Creative Commons „Uveďte autora“ 4.0.](https://creativecommons.org/licenses/by/4.0/deed.cs) <br><br>

Zdroj:<br>
Veřejné licence v České republice, verze 2.0<br>
Kolektiv autorů: Matěj Myška, Radim Polčák,<br>
Jaromír Šavelka, Libor Kyncl a Iveta Sviráková<br>
str.55<br>

</div>

Proto budu pro moji činnost používat licenci CC „Uveďte autora“ 4.0.
Název této licence je překládán i jako [CC Uveďtě původ 4.0.](https://creativecommons.org/licenses/by/4.0/deed.cs)

<div id="anchor-prekazka" markdown="1">
### PŘEKÁŽKA
</div>

Nejsem vlastníkem videí, ke kterým jsem titulky vytvořil. Vlastníkem těchto videí je Buddhistická společnost Západní Austrálie. Proto nemůžu být ani vlastníkem celého textu českých titulků. A proto nemůžu celý text těchto titulků publikovat pod licencí CC Uveďte původ 4.0. <br><br>

Dá se to nějak vyřešit?<br><br>

Mohl bych publikovat pod licencí CC Uveďte původ 4.0 jenom práci, kterou jsem na titulcích odvedl?

<div id="anchor-dobry-dusledek" markdown="1">
### DOBRÝ DŮSLEDEK
</div>

Pokud bych mohl zvěřejnit pod licencí CC Uveďte původ 4.0. jenom
moji práci na titulcích, mělo by to jeden velmi dobrý důsledek.<br><br>

V budoucnosti by v České republice mohl dostat povolení požívat
videa BSZA někdo další. Pokud by se tak stalo, nemuseli by se mě
držitelé tohoto povolení ptát i na moje povolení. Moje povolení by bylo
garantováno zveřejněním mojí práce za podmínek licence CC Uveďte původ
4.0.
