<div id="mili-priznivci"> Milí příznivci Buddhova učení,</div>

tuto stránku jsem začal tvořit pro všechny, kteří se společně se mnou podílejí na tvorbě [YouTube kanálu PANDITA CZ](https://www.youtube.com/channel/UC1IIp3Yo_PaJPsEU9BUk1ew) nebo by se na jeho tvorbě chtěli podílet. Je také pro všechny, kteří uvažují o tom, že by podobný projekt sami založili.

<div id="anchor-pandita" markdown="1" >
### Pandita CZ
</div>

Mým záměrem je publikovat na PANDITA CZ vzdělávací materiály o théravádovém buddhismu, který čerpá své duchovní kořeny v Tipitace, neboli Pálijském kánonu. Tento typ buddhismu je dominantní v zemích jižní a jihovýchodní Asie (Thajsko, Barma, Kambodža, Laos a Srí Lanka), a proto je také někdy nazýván jako „jižní buddhismus“.<br><br>

Inspiruje mě velmi úspěšný polský [YouTube kanál Sasana.pl](https://www.youtube.com/user/sasanaPL). Některá videa na tomto kanálu mají ke dni zveřejnění této stránky (8.7.2021) více než jeden milion zobrazení a celý kanál má více než 91 tisíc odběratelů.
